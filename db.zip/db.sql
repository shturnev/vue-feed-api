-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.7.20 - MySQL Community Server (GPL)
-- Операционная система:         Win64
-- HeidiSQL Версия:              9.5.0.5237
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Дамп структуры базы данных vue-api
CREATE DATABASE IF NOT EXISTS `vue-api` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `vue-api`;

-- Дамп структуры для таблица vue-api.clients
CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `user_id` int(6) NOT NULL DEFAULT '0',
  `date` bigint(15) NOT NULL DEFAULT '0',
  `public_key` varchar(250) DEFAULT NULL,
  `title` varchar(250) DEFAULT NULL,
  `private_key` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_clients_users` (`user_id`),
  CONSTRAINT `FK_clients_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы vue-api.clients: ~4 rows (приблизительно)
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT IGNORE INTO `clients` (`id`, `user_id`, `date`, `public_key`, `title`, `private_key`) VALUES
	(3, 7, 1521196847, 'c2668202225ef561304d83e021ab39c8ddce3a50e61b580fe903d56e1a2ca2f7', 'dsfd sfds sdfsdfdsf', '22d2bc852ac7a51314b24e13b30878201c1ffa4c1f48f257007af4533ab4cd59'),
	(4, 7, 1521196851, 'e5326bfe72b1dcd4a6a3ff6068c95ae73a141bb6dd08cbe95604e31584ec0489', '54dfd fdf df d', '65111ec174624adcf9a6f956d2368b32fc9c6e976e15ec3eb18879e34a001521'),
	(5, 7, 1521196857, 'ab2a043da4648ac12dbec029f9729b16a9f3c4ee3c4ee119dad3e4316d0d40fb', '2335sadsdsa dsad sad sad', 'fb5c4719663f26bd3cc104be5623fc0ffe1eefcc59f8d47237b428872bf0e464'),
	(6, 7, 1521197697, 'bfdfd2f24526f3dbd7a6339297a640a54d00a2206ba26d818c9acce235280bd9', 'fgdf fg&amp;&amp;&amp;&amp;', 'c1d0920dc08e442e9fa8f8d4403bb917697f1b04597cee788c08fbe534bbac95');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;

-- Дамп структуры для таблица vue-api.feed
CREATE TABLE IF NOT EXISTS `feed` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `client_id` int(6) NOT NULL DEFAULT '0',
  `user_id` int(6) NOT NULL DEFAULT '0',
  `protected` int(2) NOT NULL DEFAULT '0',
  `date` bigint(15) NOT NULL DEFAULT '0',
  `title` varchar(250) DEFAULT NULL,
  `text` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_feed_clients` (`client_id`),
  CONSTRAINT `FK_feed_clients` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы vue-api.feed: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `feed` DISABLE KEYS */;
INSERT IGNORE INTO `feed` (`id`, `client_id`, `user_id`, `protected`, `date`, `title`, `text`) VALUES
	(1, 6, 7, 0, 1521285309, 'ппрпрпррппп', 'фыв фывфыв фывыв ыфвфыв ыфв ыфв ы ы'),
	(2, 6, 7, 0, 1521285361, 'ппрпрпррппп', 'фыв фывфыв фывыв ыфвфыв ыфв ыфв ы ы'),
	(3, 6, 7, 0, 1521285397, 'test title', 'long text text');
/*!40000 ALTER TABLE `feed` ENABLE KEYS */;

-- Дамп структуры для таблица vue-api.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `verified` int(2) NOT NULL DEFAULT '0',
  `email` varchar(50) DEFAULT NULL,
  `pass` varchar(250) DEFAULT NULL,
  `token` varchar(250) DEFAULT NULL,
  `date` bigint(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы vue-api.users: ~2 rows (приблизительно)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT IGNORE INTO `users` (`id`, `verified`, `email`, `pass`, `token`, `date`) VALUES
	(7, 1, 'sht_job@ukr.net', '$2y$10$lDCkaqYFouGWTzietV.EmOhfiA.PLjU/lV0Y/rFHDzhWnj89VadTa', '1b01088b75454346437ae63a15120012', 1521117782);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
