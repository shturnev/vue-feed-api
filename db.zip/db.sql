-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.7.20 - MySQL Community Server (GPL)
-- Операционная система:         Win64
-- HeidiSQL Версия:              9.5.0.5237
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Дамп структуры базы данных vue-api
CREATE DATABASE IF NOT EXISTS `vue-api` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `vue-api`;

-- Дамп структуры для таблица vue-api.clients
CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `user_id` int(6) NOT NULL DEFAULT '0',
  `date` bigint(15) NOT NULL DEFAULT '0',
  `public_key` varchar(250) DEFAULT NULL,
  `title` varchar(250) DEFAULT NULL,
  `private_key` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_clients_users` (`user_id`),
  CONSTRAINT `FK_clients_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы vue-api.clients: ~4 rows (приблизительно)
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT IGNORE INTO `clients` (`id`, `user_id`, `date`, `public_key`, `title`, `private_key`) VALUES
	(3, 7, 1521196847, 'c2668202225ef561304d83e021ab39c8ddce3a50e61b580fe903d56e1a2ca2f7', 'dsfd sfds sdfsdfdsf', '22d2bc852ac7a51314b24e13b30878201c1ffa4c1f48f257007af4533ab4cd59'),
	(4, 7, 1521196851, 'e5326bfe72b1dcd4a6a3ff6068c95ae73a141bb6dd08cbe95604e31584ec0489', '54dfd fdf df d', '65111ec174624adcf9a6f956d2368b32fc9c6e976e15ec3eb18879e34a001521'),
	(5, 7, 1521196857, 'ab2a043da4648ac12dbec029f9729b16a9f3c4ee3c4ee119dad3e4316d0d40fb', '2335sadsdsa dsad sad sad', 'fb5c4719663f26bd3cc104be5623fc0ffe1eefcc59f8d47237b428872bf0e464'),
	(6, 7, 1521197697, 'bfdfd2f24526f3dbd7a6339297a640a54d00a2206ba26d818c9acce235280bd9', 'fgdf fg&amp;&amp;&amp;&amp;', 'c1d0920dc08e442e9fa8f8d4403bb917697f1b04597cee788c08fbe534bbac95');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;

-- Дамп структуры для таблица vue-api.feed
CREATE TABLE IF NOT EXISTS `feed` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `client_id` int(6) NOT NULL DEFAULT '0',
  `user_id` int(6) NOT NULL DEFAULT '0',
  `protected` int(2) NOT NULL DEFAULT '0',
  `date` bigint(15) NOT NULL DEFAULT '0',
  `title` varchar(250) DEFAULT NULL,
  `text` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_feed_clients` (`client_id`),
  FULLTEXT KEY `title` (`title`,`text`),
  CONSTRAINT `FK_feed_clients` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы vue-api.feed: ~14 rows (приблизительно)
/*!40000 ALTER TABLE `feed` DISABLE KEYS */;
INSERT IGNORE INTO `feed` (`id`, `client_id`, `user_id`, `protected`, `date`, `title`, `text`) VALUES
	(1, 6, 7, 0, 1521396931, 'ппрпрпррппп', 'фыв фывфыв фывыв ыфвфыв ыфв ыфв ы ы'),
	(4, 6, 7, 0, 1521383506, 'voluptas nobis atque consequuntur esse nulla ducimus', 'What WILL become of me?\\\' Luckily for Alice, the little glass box that was lying on the bank, and of having nothing to what I like\\"!\\\' \\\'You might just as she couldn\\\'t answer either question, it didn\\\'t.'),
	(5, 6, 7, 0, 1521383514, 'voluptatum sed voluptate voluptas pariatur facere quidem', 'Dormouse. \\\'Write that down,\\\' the King and the Queen was to find that the hedgehog a blow with its mouth and began to repeat it, but her voice sounded hoarse and strange, and the little thing sat.'),
	(6, 6, 7, 0, 1521383516, 'molestias fugiat tempore vel consectetur fugiat facilis', 'Alice joined the procession, wondering very much of it in a large caterpillar, that was lying under the window, I only wish it was,\\\' he said. \\\'Fifteenth,\\\' said the Queen. \\\'Sentence first--verdict.'),
	(7, 6, 7, 0, 1521383518, 'quia velit ut eaque et eos facilis', 'Alice to herself. \\\'Of the mushroom,\\\' said the Mouse only shook its head down, and felt quite relieved to see anything; then she walked up towards it rather timidly, saying to herself \\\'This is Bill,\\\'.'),
	(8, 6, 7, 0, 1521383523, 'nam laborum maiores repellendus ab voluptate voluptatum', 'Now I growl when I\\\'m angry. Therefore I\\\'m mad.\\\' \\\'I call it sad?\\\' And she thought of herself, \\\'I wonder if I\\\'ve kept her waiting!\\\' Alice felt a violent shake at the cook had disappeared. \\\'Never.'),
	(9, 6, 7, 0, 1521383550, 'molestiae dicta qui expedita nostrum modi culpa', 'March Hare. Alice sighed wearily. \\\'I think I can find them.\\\' As she said to herself \\\'That\\\'s quite enough--I hope I shan\\\'t grow any more--As it is, I can\\\'t understand it myself to begin lessons:.'),
	(10, 6, 7, 0, 1521383557, 'qui sed eaque voluptatibus quasi quia sed', 'I get SOMEWHERE,\\\' Alice added as an explanation; \\\'I\\\'ve none of them attempted to explain the mistake it had fallen into the garden. Then she went in search of her voice, and see that she still held.'),
	(11, 6, 7, 0, 1521383558, 'voluptas optio quia molestiae vero recusandae nam', 'GAVE HER ONE, THEY GAVE HIM TWO--\\" why, that must be a letter, after all: it\\\'s a set of verses.\\\' \\\'Are they in the sea. But they HAVE their tails in their mouths. So they had any dispute with the.'),
	(12, 6, 7, 0, 1521383566, 'nisi deserunt voluptates harum ut dolor cumque', 'I\\\'m not myself, you see.\\\' \\\'I don\\\'t like it, yer honour, at all, at all!\\\' \\\'Do as I get it home?\\\' when it had grown in the window?\\\' \\\'Sure, it\\\'s an arm, yer honour!\\\' (He pronounced it \\\'arrum.\\\') \\\'An.'),
	(13, 6, 7, 0, 1521383577, 'voluptates eos provident sint delectus est sequi', 'Alice. \\\'I don\\\'t think it\\\'s at all comfortable, and it put the hookah out of the way--\\\' \\\'THAT generally takes some time,\\\' interrupted the Gryphon. \\\'Well, I shan\\\'t go, at any rate, the Dormouse denied.'),
	(14, 6, 7, 1, 1521383581, 'blanditiis voluptatum aliquam illo occaecati ut at', 'Hatter: \\\'but you could draw treacle out of sight before the end of the baby, it was getting so used to it in a hoarse, feeble voice: \\\'I heard every word you fellows were saying.\\\' \\\'Tell us a story.\\\'.'),
	(15, 6, 7, 1, 1521383583, 'et id qui inventore dolorem dignissimos sed', 'It was opened by another footman in livery, with a trumpet in one hand and a large dish of tarts upon it: they looked so good, that it led into the open air. \\\'IF I don\\\'t want YOU with us!\\"\\\' \\\'They.');
/*!40000 ALTER TABLE `feed` ENABLE KEYS */;

-- Дамп структуры для таблица vue-api.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `verified` int(2) NOT NULL DEFAULT '0',
  `email` varchar(50) DEFAULT NULL,
  `pass` varchar(250) DEFAULT NULL,
  `token` varchar(250) DEFAULT NULL,
  `date` bigint(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы vue-api.users: ~2 rows (приблизительно)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT IGNORE INTO `users` (`id`, `verified`, `email`, `pass`, `token`, `date`) VALUES
	(7, 1, 'sht_job@ukr.net', '$2y$10$lDCkaqYFouGWTzietV.EmOhfiA.PLjU/lV0Y/rFHDzhWnj89VadTa', '1b01088b75454346437ae63a15120012', 1521117782);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
