-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.7.20 - MySQL Community Server (GPL)
-- Операционная система:         Win64
-- HeidiSQL Версия:              9.5.0.5237
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Дамп структуры базы данных vue-api
CREATE DATABASE IF NOT EXISTS `vue-api` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `vue-api`;

-- Дамп структуры для таблица vue-api.clients
CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `user_id` int(5) DEFAULT NULL,
  `date` bigint(15) DEFAULT NULL,
  `public_key` varchar(250) DEFAULT NULL,
  `private_key` varchar(250) DEFAULT NULL,
  `title` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clients_users_id_fk` (`user_id`),
  CONSTRAINT `clients_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы vue-api.clients: ~4 rows (приблизительно)
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT IGNORE INTO `clients` (`id`, `user_id`, `date`, `public_key`, `private_key`, `title`) VALUES
	(21, 1, 1521647984, 'bd18fd90e8db01359ca21f682499abd8c1f4845dc849bb7167e14ca9944e7a21', '969a5d7a003e6ecaab166fb31bf625febbc4e510048b1bdb92c0ecd50de98e12', 'gdfg df gdfg df g'),
	(22, 1, 1521647988, '6273f055259d521633471414ed3ca2163682b0f6b81b777a1af5fd237e519b78', '631e1be3db0984f8f5234cee00e0a83873f0259c7f7680e41d3568c658aef00f', 'j ghjghj ghj'),
	(23, 1, 1521647992, '6215b5e6aa8518fbc9d3842b22522492bdc526422f848eba6d532e1562eb6df9', '2744a4d285c6e950fdc44e94688235ef89830b12f0c00ef7196dd7171606fd62', 'fgdsfsd fsdf sdf');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;

-- Дамп структуры для таблица vue-api.feed
CREATE TABLE IF NOT EXISTS `feed` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `client_id` int(5) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `text` text,
  `date` bigint(15) NOT NULL,
  `protected` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_feed_clients` (`client_id`),
  FULLTEXT KEY `title` (`title`,`text`),
  CONSTRAINT `FK_feed_clients` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы vue-api.feed: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `feed` DISABLE KEYS */;
INSERT IGNORE INTO `feed` (`id`, `client_id`, `title`, `text`, `date`, `protected`) VALUES
	(3, 21, 'Atque voluptatibus doloremque vel dolor. Doloribus officia quisquam fuga eveniet id omnis. Iure harum error laborum omnis totam omnis.', 'Alice very politely; but she ran off as hard as she could, for the rest of it had struck her foot! She was moving them about as she spoke. Alice did not dare to laugh; and, as they used to say.\\\' \\\'So.', 1522092952, 1),
	(4, 21, 'Ducimus et esse aut voluptatem omnis dolorem.', 'Said the mouse doesn\\\'t get out.\\" Only I don\\\'t care which happens!\\\' She ate a little before she gave one sharp kick, and waited till the Pigeon in a low, hurried tone. He looked at Alice, as she.', 1522092973, 0),
	(5, 21, 'sds asd asd asd asd asd', 'sdas dasd asd asd asd asd', 1522093279, 0);
/*!40000 ALTER TABLE `feed` ENABLE KEYS */;

-- Дамп структуры для таблица vue-api.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `email` varchar(150) DEFAULT NULL,
  `pass` varchar(250) DEFAULT NULL,
  `token` varchar(250) DEFAULT NULL,
  `verified` int(2) DEFAULT '0',
  `date` bigint(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы vue-api.users: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT IGNORE INTO `users` (`id`, `email`, `pass`, `token`, `verified`, `date`) VALUES
	(1, 'sht_job@ukr.net', '$2y$10$/kHwZI4U/xx67gecYTf4QucxFr.c8eQpmEmOQp3vsjR7F6VKRMv2m', '49f8cb80ba6b24a56cf4693c50e0203a', 1, 1521624870);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
