-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.7.20 - MySQL Community Server (GPL)
-- Операционная система:         Win64
-- HeidiSQL Версия:              9.5.0.5237
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Дамп структуры базы данных vue-api
CREATE DATABASE IF NOT EXISTS `vue-api` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `vue-api`;

-- Дамп структуры для таблица vue-api.clients
CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `user_id` int(5) DEFAULT NULL,
  `date` bigint(15) DEFAULT NULL,
  `public_key` varchar(250) DEFAULT NULL,
  `private_key` varchar(250) DEFAULT NULL,
  `title` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clients_users_id_fk` (`user_id`),
  CONSTRAINT `clients_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы vue-api.clients: ~1 rows (приблизительно)
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT IGNORE INTO `clients` (`id`, `user_id`, `date`, `public_key`, `private_key`, `title`) VALUES
	(1, 1, 1521630373, 'ba35447d6be4d074fb3c8ea6c471e21af0d14f71d9d0b5dc1994b8591c7f3857', '81b4b57678db886a42c4fbf710cd4a45b33b58df1798dda4a31b1c42586ee362', 'voluptatibus dignissimos et');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;

-- Дамп структуры для таблица vue-api.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `email` varchar(150) DEFAULT NULL,
  `pass` varchar(250) DEFAULT NULL,
  `token` varchar(250) DEFAULT NULL,
  `verified` int(2) DEFAULT '0',
  `date` bigint(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы vue-api.users: ~1 rows (приблизительно)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT IGNORE INTO `users` (`id`, `email`, `pass`, `token`, `verified`, `date`) VALUES
	(1, 'sht_job@ukr.net', '$2y$10$/kHwZI4U/xx67gecYTf4QucxFr.c8eQpmEmOQp3vsjR7F6VKRMv2m', '49f8cb80ba6b24a56cf4693c50e0203a', 1, 1521624870);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
