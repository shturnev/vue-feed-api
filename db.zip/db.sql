-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.7.20 - MySQL Community Server (GPL)
-- Операционная система:         Win64
-- HeidiSQL Версия:              9.5.0.5237
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Дамп структуры базы данных vue-api
CREATE DATABASE IF NOT EXISTS `vue-api` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `vue-api`;

-- Дамп структуры для таблица vue-api.clients
CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `user_id` int(6) NOT NULL DEFAULT '0',
  `date` bigint(15) NOT NULL DEFAULT '0',
  `public_key` varchar(250) DEFAULT NULL,
  `title` varchar(250) DEFAULT NULL,
  `private_key` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_clients_users` (`user_id`),
  CONSTRAINT `FK_clients_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы vue-api.clients: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT IGNORE INTO `clients` (`id`, `user_id`, `date`, `public_key`, `title`, `private_key`) VALUES
	(1, 7, 1521139109, '0f314e05e8c41b9ad851b30fbfc7a67c9959393cf8b225ef6c7516af0f74689c', 'testttttt', 'c39cab12a18b3f359c10c09a2b242fd41d02c83001b1af2f9c3833d857884629');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;

-- Дамп структуры для таблица vue-api.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `verified` int(2) NOT NULL DEFAULT '0',
  `email` varchar(50) DEFAULT NULL,
  `pass` varchar(250) DEFAULT NULL,
  `token` varchar(250) DEFAULT NULL,
  `date` bigint(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы vue-api.users: ~1 rows (приблизительно)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT IGNORE INTO `users` (`id`, `verified`, `email`, `pass`, `token`, `date`) VALUES
	(7, 1, 'sht_job@ukr.net', '$2y$10$lDCkaqYFouGWTzietV.EmOhfiA.PLjU/lV0Y/rFHDzhWnj89VadTa', '1b01088b75454346437ae63a15120012', 1521117782);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
